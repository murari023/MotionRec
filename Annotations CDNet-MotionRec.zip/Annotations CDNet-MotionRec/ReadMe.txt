The labels are in line with the "CSV datasets" annotation format.

https://github.com/fizyr/keras-retinanet#csv-datasets